# Tugas 2 Submission Open Music Dicoding Fundamental Backend

## Cara Penggunaan.

run command `npm install` untuk menginstall dependency.
run command `npm run migrate up` untuk menjalankan query database.

## Yang harus dikerjakan pada proyek ini.

1. Kriteria 1 : Registrasi dan Autentikasi Pengguna
2. Kriteria 2 : Pengelolaan Data Playlist 
3. Kriteria 3 : Menerapkan Foreign Key
